const mongoose = require('mongoose');
const URL = 'mongodb+srv://amit:amit123456@cluster0.y6jwf5b.mongodb.net/pizzadb?retryWrites=true&w=majority';
mongoose.connect(URL,{maxPoolSize:5},(err)=>{
    if(err){
        console.log('DB Error ', err);
    }
    else{
        console.log('DB Connection Created...');
    }
});
module.exports = mongoose;