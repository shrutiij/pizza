const UserModel = require('../models/user');
module.exports = {
    add(userObject){
        var promise = UserModel.create(userObject);
        return promise;
    },
    find(userObject, response){
        UserModel.findOne({userid:userObject.userid, password:userObject.password},(err, doc)=>{
            if(err){
                response.json({message:'Some DB Error  '});
            }
            else if(doc){
                response.json({message:'Welcome '+userObject.userid});
            }
            else{
                response.json({message:'Invalid Userid or Password'});
            }
        })
    },
    update(userObject){
        UserModel.updateOne({userid:userObject.userid},{password:userObject.password}, (err)=>{
            if(err){

            }
            else{
                
            }
        });
    },
    remove(userid){

    }
}